<!DOCTYPE html>
<html lang="en">
<?php include './source/base_head.php'; ?>
<body>
    <!-- Page Wrapper -->
    <div id="page" class="animsition equal" data-loader-type="loader2" data-page-loader-text="T2 Gallery" data-animsition-in="fade-in-up-sm" data-animsition-out="fade-out-up-sm" style="transform-origin: 50% 50vh;">
    <div id="top"></div>
        <!-- Home Section -->
        <?php include './source/landing_intro.php'; ?>
        <!--/ End Home Section -->
        <!-- Navbar -->
        <?php include './source/nav.php'; ?>
        <!--/ End Navbar -->
        <div id="page-2">
            <!-- About Section -->
            <section id="about-section" class="about-section section">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            we are here to capture your moments
                        </div>
                        <div>
                            <h2 class="section-title-heading">about <span>t2 Studios</span></h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12 wow fadeInUp margin-bottom-xs-40 text-center">
                            <blockquote class=" about-quote wow fadeInUp" data-wow-delay="0s">
                                <p>"Relive your moments with magical experience. A yound passionate and artistic creq who loves to exploit.</p><p>A techinically sound team on and off set. Our priority is to give warm and comfortable ambiance"</p>
                            </blockquote>
                            <!--<p class="section-text wow fadeInUp" data-wow-delay=".3s">Provident saepe deserunt, accusamus quiatetur, mollitia fugit sedar itectoia samus one ipsa facilisis eot.</p>-->
                        </div>
                    </div>
                    <!--/.row -->
                </div>
                <!--/.container -->
            </section>
            <!--/ End About Section --> 
            <hr />
            <!-- Services Section -->
            <section id="services-section" class="services-section section">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            well covered and efficient
                        </div>
                        <div>
                            <h1 class="section-title-heading"><span>Our</span> Services</h1>
                        </div>
                    </div>
                    <div class="services-section-items padding-top-sm-10 row">
                        <div class="services-section-item col-sm-4 wow fadeInUpRightScale">
                            <div class="services-section-item-icon">
                                <i class="icon-picture"></i>
                            </div>
                            <h4 class="services-item-title font-second">Couple shoots</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-heart"></i>
                            </div>
                            <h4 class="services-item-title font-second">Marriage</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpLeftScale">
                            <div class="services-section-item-icon">
                                <i class="icon-aperture"></i>
                            </div>
                            <h4 class="services-item-title font-second">Candid</h4>
                            <div class="services-section-item-text">
                                <p>Being one's self is what takes to be a perfect candid moments, T2 makes sure your lively moments are captured.</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpLeftScale">
                            <div class="services-section-item-icon">
                                <i class="icon-lightbulb"></i>
                            </div>
                            <h4 class="services-item-title font-second">Events</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-focus"></i>
                            </div>
                            <h4 class="services-item-title font-second">Infants & Kids Shoot</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-anchor"></i>
                            </div>
                            <h4 class="services-item-title font-second">Product Shoot</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                    </div>
                    <!--/.row -->
                </div>
                <!--/.container -->
            </section>
            <!--/ End Services Section -->
            <hr />
            <!--Start Works Section -->
            <section id="portfolio-section" class="portfolio-section section text-center no-padding-bottom">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            check it out
                        </div>
                        <div>
                            <h1 class="section-title-heading">our <span>portfolio</span></h1>
                        </div>
                    </div>
                </div>
                <!-- /.container -->
                <!-- Works Items -->
                <ul id="portfolio-container" class="portfolio-container masonry clearlist row portfolio-hover-effect">
                    <li class="portfolio-item photo video col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x360.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">Couple Shoots</h3>
                            <div class="portfolio-item-detail">
                                <p>Collection...!</p>
                                <!-- LightBox Button -->
                                <a href="img/portfolio/work01_lg.jpg" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="img/portfolio/work01_lg.jpg"></a>
                                <!--/ End LightBox Button -->
                                <a href="project_page.html" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                    <li class="portfolio-item photo video col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x720.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">Marriage</h3>
                            <div class="portfolio-item-detail">
                                <p>Collection...!</p>
                                <!-- LightBox Button -->
                                <a href="img/portfolio/work01_lg.jpg" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="img/portfolio/work01_lg.jpg"></a>
                                <!--/ End LightBox Button -->
                                <a href="project_page.html" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                    <li class="portfolio-item video col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x360.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">Candid</h3>
                            <div class="portfolio-item-detail">
                                <p>Nihil odio ipsa fugiat</p>
                                <!-- LightBox Button -->
                                <a href="https://www.youtube.com/watch?v=3FaVQcEjHUc" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1"></a>
                                <!--/ End LightBox Button -->
                                <a href="./projects/candid.php" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                    <li class="portfolio-item photo video col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x720.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">Product</h3>
                            <div class="portfolio-item-detail">
                                <p>Collection...!</p>
                                <!-- LightBox Button -->
                                <a href="img/portfolio/work01_lg.jpg" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="img/portfolio/work01_lg.jpg"></a>
                                <!--/ End LightBox Button -->
                                <a href="project_page.html" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                    <li class="portfolio-item web-design video col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x360.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">infants & Kids</h3>
                            <div class="portfolio-item-detail">
                                <p>Nobis blanditiis rerum dolor</p>
                                <!-- LightBox Button -->
                                <a href="img/portfolio/work04_lg.jpg" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="img/portfolio/work04_lg@2x.jpg"></a>
                                <!--/ End LightBox Button -->
                                <a href="project_page.html" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                    <li class="portfolio-item photo web-design col-sm-6 col-md-3 col-xs-12">
                        <div class="portfolio-item-img">
                            <img src="img/400x360.png" alt="portfolio" />
                        </div>
                        <div class="portfolio-item-info font-second">
                            <h3 class="portfolio-item-title">Events</h3>
                            <div class="portfolio-item-detail">
                                <p>Nobis blanditiis rerum dolor</p>
                                <!-- LightBox Button -->
                                <a href="https://vimeo.com/31240369" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1"></a>
                                <!--/ End LightBox Button -->
                                <a href="project_page.html" class="animsition-link icon-attachment"></a>
                            </div>
                        </div>
                    </li>
                    <!--/ End Work Item -->
                </ul>
                <!--/ End Works Items -->
            </section>
            <!--/ End Works Section -->
            <!-- Project Order Section -->
            <div class="project-order-section in-page-scroll small-section text-center">
                <a href="#contact-section" class="btn btn-animated btn-split btn-colored ripple-alone" data-text="Have a Project in Mind?"><span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;let's do it then&nbsp;..&nbsp;&nbsp;&nbsp;&nbsp;</span></a>
            </div>
            <!--/ End Project Order Section -->
            <!-- Team Section -->
            <section id="team-section" class="team-section section">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="section-title">
                                <div class=" section-title-more">
                                    get to know
                                </div>
                                <div>
                                    <h2 class="section-title-heading"><span> our </span>family </h2>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6 margin-bottom-xs-40">
                            <p class="section-text">“A young passionate and artistic crew who loves to exploit.  A technically strong team on and off set”</p>
                        </div>
                    </div>
                    <!-- /.col -->
                    <!-- /.row -->
                    <!-- Team Items -->
                    <div class="team-items">
                        <!-- Team Carousel -->
                        <div id="team-carousel" class="team-carousel owl-carousel carousel dots-under">
                            <!-- Team Item -->
                            <div class="team-item">
                                <!-- Team Item Image -->
                                <div class="team-item-img">
                                    <img src="img/team/Avi.jpg" alt="team member" />
                                </div>
                                <!--/ End Team Item Imagee -->
                                <!-- Team Item Name -->
                                <div class="team-item-name font-second">
                                    <h4 class="">Avi</h4>
                                    <span>Photographer</span>
                                </div>
                                <!--/ End Team Item Name -->
                                <!-- Team Item Info -->
                                <div class="team-item-info">
                                    <div class="team-item-text">
                                        <h3 class="font-second">Time to <span>capture..</span></h3>
                                        <p>Seeking your happiness and will share your memory as digital format.</p>
                                    </div>
                                    <ul class="team-item-social clearlist">
                                        <li>
                                            <a href="#." class="fa fa-facebook-square"></a>
                                        </li>
                                        <li>
                                            <a href="#." class=" fa fa-twitter"></a>
                                        </li>
                                        <li>
                                            <a href="#." class="fa fa-pinterest"></a>
                                        </li>
                                    </ul>
                                </div>
                                <!--/ End Team Item Info -->
                            </div>
                            <!--/ End Team Item -->
                            <!-- Team Item -->
                            <div class="team-item">
                                <!-- Team Item Image -->
                                <div class="team-item-img">
                                    <img src="img/team/Deepi.jpg" alt="team member" />
                                </div>
                                <!--/ End Team Item Image -->
                                <!-- Team Item Name -->
                                <div class="team-item-name font-second">
                                    <h4 class="">Sathya</h4>
                                    <span>Fashion Designer</span>
                                </div>
                                <!--/ End Team Item Name -->
                                <!-- Team Item Info -->
                                <div class="team-item-info">
                                    <div class="team-item-text">
                                        <h3 class="font-second"><span>Sync with</span> real nature</h3>
                                        <p>We never used to change the real looks and colors, we have a different vision and perspective of nature.</p>
                                    </div>
                                    <ul class="team-item-social clearlist">
                                        <li>
                                            <a href="#." class="fa fa-facebook-square"></a>
                                        </li>
                                        <li>
                                            <a href="#." class=" fa fa-twitter"></a>
                                        </li>
                                        <li>
                                            <a href="#." class="fa fa-skype"></a>
                                        </li>
                                        <li>
                                            <a href="#." class="fa fa-pinterest"></a>
                                        </li>
                                    </ul>
                                </div>
                                <!--/ End Item Info -->
                            </div>
                            <!--/ End Team Item -->
                            <!-- Team Item -->
                            <div class="team-item">
                                <!-- Team Item Image -->
                                <div class="team-item-img">
                                    <img src="img/team/Sathiya.jpg" alt="team member" />
                                </div>
                                <!--/ End Team Item Image -->
                                <!-- Team Item Name -->
                                <div class="team-item-name font-second">
                                    <h4 class="">Sathiya</h4>
                                    <span>Photographer</span>
                                </div>
                                <!--/ End Team Item Name -->
                                <!-- Team Item Info -->
                                <div class="team-item-info">
                                    <div class="team-item-text">
                                        <h3 class="font-second">Chooo Cute! <span>click..</span></h3>
                                        <p>The shutter is always open to capture you, because its never happen again</p>
                                    </div>
                                    <ul class="team-item-social clearlist">
                                        <li>
                                            <a href="#." class=" fa fa-twitter"></a>
                                        </li>
                                        <li>
                                            <a href="#." class="fa fa-skype"></a>
                                        </li>
                                        <li>
                                            <a href="#." class="fa fa-pinterest"></a>
                                        </li>
                                    </ul>
                                </div>
                                <!--/ End Item Info -->
                            </div>
                            <!--/ End Team Item -->
                            <!-- Team Item -->
                        </div>
                        <!--/ End Team Carousel -->
                    </div>
                    <!--/ End Team Items -->
                </div>
                <!-- /.container -->
            </section>
            <!--/ End Team Section -->
            <hr />
            <!-- Process Section -->
            <section id="process-section" class="process-section section">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            how we are working
                        </div>
                        <div>
                            <h1 class="section-title-heading"><span>process</span> flow</h1>
                        </div>
                    </div>
                    <div class="position-relative padding-bottom-40 padding-top-100 padding-top-sm-120">
                        <!-- process headers -->
                        <ul class="process-labels font-second">
                            <!-- change [data-active] and list item to a same value -->
                            <li data-que="1" class="process-label-active wow fadeInDown" data-wow-offset="100" data-wow-delay="0s">
                                <i class="icon-aperture">
                            <i class="icon-aperture icon-shade"></i>
                                </i>
                                <span data-active="photo&nbsp;shoots"> photo&nbsp;shoots</span>
                            </li>
                            <li data-que="2" class=" wow fadeInDown" data-wow-offset="100" data-wow-delay=".15s">
                                <i class="icon-pictures">
                            <i class="icon-pictures icon-shade"></i>
                                </i>
                                <span data-active="best&nbsp;pictures"> best&nbsp;pictures</span>
                            </li>
                            <li data-que="3" class=" wow fadeInDown" data-wow-offset="100" data-wow-delay=".3s">
                                <i class="icon-tools">
                            <i class="icon-tools icon-shade"></i>
                                </i>
                                <span data-active="art&nbsp;work"> art&nbsp;work</span>
                            </li>
                            <li data-que="4" class=" wow fadeInDown" data-wow-offset="100" data-wow-delay=".45s">
                                <i class="icon-printer">
                            <i class="icon-printer icon-shade"></i>
                                </i>
                                <span data-active="printing"> printing</span>
                            </li>
                        </ul>
                        <!--/ End process headers -->
                        <!-- process bar -->
                        <div class="line-process-parent">
                            <div class="line-process"></div>
                        </div>
                        <!--/ End process bar -->
                    </div>
                </div>
                <!-- /.container -->
            </section>
            <!--/ End Process Section -->
            <!-- Clients Testimonials Section -->
            <section id="client-testimonials" class="client-testimonials section  overlay">
                <!-- Parallax Image Background -->
                <div class="parallax-section-bg client-testimonials-bg index11 overlay full-screen" data-center="transform: translate3d(0px, -50%, 0px)" data-top-bottom="transform: translate3d(0px, -25%, 0px)" data-bottom-top="transform: translate3d(0px, -75%, 0px)" data-anchor-target="#client-testimonials"></div>
                <!--/ End Parallax Image Background -->
                <div class="container">
                    <div class="section-title padding-bottom-40">
                        <div class=" section-title-more">
                            Testimonial
                        </div>
                        <div>
                            <h1 class="section-title-heading">our <span>clients</span></h1>
                        </div>
                    </div>
                </div>
                <!--/ .container -->
                <div id="testimonials" class="testimonials owl-carousel carousel">
                    <div class="testimo-item">
                        <div class="container">
                            <blockquote>
                                <p>"Aciunt ipsum dolore doloribus eius ad hic quidem. Quaerat ea explicabo, blanditiis laborum ut accusamus velbus eius adhic quidemu mollitia quae."</p>
                                <footer class="">Natalia Oswald
                                    <cite title="Source Title">High point co.</cite>
                                </footer>
                            </blockquote>
                        </div>
                        <!--/ .container -->
                    </div>
                    <!--/ End Testimonials Item -->
                    <div class="testimo-item">
                        <div class="container">
                            <blockquote>
                                <p>"Ratione, iure obcaecati laborum adipisci ipsam illo, accusantium sit, molestiae minima perspiciatis nulla temporibus illum. Molestias totam suscipit sequi, sed optio!offici."</p>
                                <footer class="">Rafael Ando
                                    <cite title="Source Title">raindrop inc.</cite>
                                </footer>
                            </blockquote>
                        </div>
                        <!--/ .container -->
                    </div>
                    <!--/ End Testimonials Item -->
                    <div class="testimo-item">
                        <div class="container">
                            <blockquote>
                                <p>"Illo fuga, enim perspiciatis et aut ad. Earum quidem minima magnam consectetur deserunt sed id amet, doloribus veritatis, eligendi omnis, voluptas illum.molestiae."</p>
                                <footer class="">Johny rich
                                    <cite title="Source Title">ennax studio</cite>
                                </footer>
                            </blockquote>
                        </div>
                        <!--/ .container -->
                    </div>
                    <!--/ End Testimonials Item -->
                </div>
                <!--/ End Testimonials Content -->
            </section>
            <!--/ End Clients Testimonials Section -->
            <hr />
            <!-- Contact Section -->
            <section id="contact-section" class="section contact-section">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            buzz
                        </div>
                        <div>
                            <h2 class="section-title-heading"><span>contact</span> us</h2>
                        </div>
                    </div>
                    <div class="row padding-bottom-sm-90">
                        <div class="col-sm-4">
                            <div class="contact-item margin-bottom-xs-40"><i class="icon-phone"></i>
                                <p>Phone: +91 - 96 77 261658
                                <br />+91 - 75 50 190604</p>
                                    <br />+91 - 98 94 533299</p>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="contact-item margin-bottom-xs-40"><i class="icon-map-pin"></i>
                                <p>#00 Vadapalani,
                                    <br />Chennai - 26, TN, India</p>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <a href="mailto:contact@t2.gallery">
                                <div class="contact-item margin-bottom-xs-40"><i class="icon-envelope"></i>
                                    <p>contact@t2.gallery</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-offset-1 col-md-10">
                            <form id="ajax-contact" class="" method="post" action="mailer.php">
                                <fieldset>
                                    <div class="row">
                                        <div class="input col-xs-12 col-sm-12 padding-bottom-xs-50 padding-bottom-40">
                                            <label class="input-label" for="name">
                                                <span class="input-label-content font-second" data-content="name">name *</span>
                                            </label>
                                            <input class="input-field" type="text" name="name" id="name" required />
                                        </div>
                                        <div class="input col-xs-12 col-sm-6 padding-bottom-xs-50 padding-bottom-50">
                                            <label class="input-label" for="email">
                                                <span class="input-label-content font-second" data-content="email">email *</span>
                                            </label>
                                            <input class="input-field" type="email" name="email" id="email" required />
                                        </div>
                                        <div class="input col-xs-12 col-sm-6 padding-bottom-xs-60 padding-bottom-50">
                                            <label class="input-label" for="Contact Number">
                                                <span class="input-label-content font-second" data-content="Contact Number">Contact Number*</span>
                                            </label>
                                            <input class="input-field" type="text" name="Contact Number" id="number" required/>
                                        </div>
                                        <div class="message col-xs-12 col-sm-12 padding-bottom-xs-40 padding-bottom-30">
                                            <label class="textarea-label font-second" for="message">message *</label>
                                            <textarea class="input-field textarea" name="message" id="message" required></textarea>
                                        </div>
                                    </div>
                                    <div id="form-messages" class="form-message"></div>
                                    <div class="col-xs-12 margin-top-30 text-center">
                                        <button id="btn-submit" type="submit" class="btn btn-animated btn-contact ripple-alone" data-text="send"><span class="btn-icon"><span class="loader-parent"><span class="loader3"></span></span>
                                            </span>
                                        </button>
                                    </div>
                                </fieldset>
                            </form>
                            <!--/ End form -->
                        </div>
                        <!--/ .col -->
                    </div>
                    <!--/ .row -->
                </div>
                <!--/ .container -->
            </section>
            <!--/ End Contact Section -->
            <!--/ Map Section -->
            <div id="map-section" class="map-section">
                <!-- map opener -->
                <div id="map-opener" class="map-mask">
                    <div class="map-opener">
                        <div class="font-second">here we are<i class="ci-icon-uniE930"></i></div>
                        <div class="font-second">close<i class="ci-icon-uniE92F"></i></div>
                    </div>
                </div>
                <!--/ End map opener -->
                <div id="google-map">
                    <div id="map-canvas" data-address="321, Vijaya Gardens, Vadapalani, Chennai, Tamil Nadu 600026"></div>
                    <div id="map-zoom-in"></div>
                    <div id="map-zoom-out"></div>
                </div>
            </div>
            <!--/ End Map Section -->
            <!-- Footer Section -->
            <?php include './source/footer_section.php';?>
            <!--/ End Footer Section -->
        </div>
        <!--/ #page-2 -->
    </div>
    <!--/ #page -->
    <!-- JS Scripts -->
    <!--< ?php include_once("analyticstracking.php") ?>-->
    <?php include './source/js.php'; ?>
    <!--/ End JS Scripts -->
</body>

</html>
