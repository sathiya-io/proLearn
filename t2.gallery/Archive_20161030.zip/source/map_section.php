<!--/ Map Section -->
<div id="map-section" class="map-section">
    <!-- map opener -->
    <div id="map-opener" class="map-mask">
        <div class="map-opener">
            <div class="font-second">here we are<i class="ci-icon-uniE930"></i></div>
            <div class="font-second">close<i class="ci-icon-uniE92F"></i></div>
        </div>
    </div>
    <!--/ End map opener -->
    <div id="google-map">
        <div id="map-canvas" data-address="321, Vijaya Gardens, Vadapalani, Chennai, Tamil Nadu 600026"></div>
        <div id="map-zoom-in"></div>
        <div id="map-zoom-out"></div>
    </div>
</div>
<!--/ End Map Section -->