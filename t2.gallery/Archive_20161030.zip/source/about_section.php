<!-- About Section -->
<section id="about-section" class="about-section section">
    <div class="container">
        <div class="section-title">
            <div class=" section-title-more">
                we are here to capture your moments
            </div>
            <div>
                <h2 class="section-title-heading">about <span>t2 Studios</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12 wow fadeInUp margin-bottom-xs-40 text-center">
                <blockquote class=" about-quote wow fadeInUp" data-wow-delay="0s">
                    <p>"Relive your moments with magical experience. A young passionate and artistic crew who loves to exploit.</p><p>A techinically sound team on and off set. Our priority is to give warm and comfortable ambiance"</p>
                </blockquote>
                <!--<p class="section-text wow fadeInUp" data-wow-delay=".3s">Provident saepe deserunt, accusamus quiatetur, mollitia fugit sedar itectoia samus one ipsa facilisis eot.</p>-->
            </div>
        </div>
        <!--/.row -->
    </div>
    <!--/.container -->
</section>
<!--/ End About Section --> 