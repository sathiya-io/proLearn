<!-- Team Section -->
<section id="team-section" class="team-section section">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="section-title">
                    <div class=" section-title-more">
                        get to know
                    </div>
                    <div>
                        <h2 class="section-title-heading"><span> our </span>family </h2>
                    </div>
                </div>
            </div>
            <!-- /.col -->
            <div class="col-sm-6 margin-bottom-xs-40">
                <p class="section-text">“A young passionate and artistic crew who loves to exploit.  A technically strong team on and off set”</p>
            </div>
        </div>
        <!-- /.col -->
        <!-- /.row -->
        <!-- Team Items -->
        <div class="team-items">
            <!-- Team Carousel -->
            <div id="team-carousel" class="team-carousel owl-carousel carousel dots-under">
                <!-- Team Item -->
                <div class="team-item">
                    <!-- Team Item Image -->
                    <div class="team-item-img">
                        <img src="img/team/Avi.jpg" alt="team member" />
                    </div>
                    <!--/ End Team Item Imagee -->
                    <!-- Team Item Name -->
                    <div class="team-item-name font-second">
                        <h4 class="">Avi</h4>
                        <span>Photographer</span>
                    </div>
                    <!--/ End Team Item Name -->
                    <!-- Team Item Info -->
                    <div class="team-item-info">
                        <div class="team-item-text">
                            <h3 class="font-second">Time to <span>capture..</span></h3>
                            <p>Seeking your happiness and will share your memory as digital format.</p>
                        </div>
                        <ul class="team-item-social clearlist">
                            <li>
                                <a href="#." class="fa fa-facebook-square"></a>
                            </li>
                            <li>
                                <a href="#." class=" fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#." class="fa fa-pinterest"></a>
                            </li>
                        </ul>
                    </div>
                    <!--/ End Team Item Info -->
                </div>
                <!--/ End Team Item -->
                <!-- Team Item -->
                <div class="team-item">
                    <!-- Team Item Image -->
                    <div class="team-item-img">
                        <img src="img/team/Deepi.jpg" alt="team member" />
                    </div>
                    <!--/ End Team Item Image -->
                    <!-- Team Item Name -->
                    <div class="team-item-name font-second">
                        <h4 class="">Sathya</h4>
                        <span>Fashion Designer</span>
                    </div>
                    <!--/ End Team Item Name -->
                    <!-- Team Item Info -->
                    <div class="team-item-info">
                        <div class="team-item-text">
                            <h3 class="font-second"><span>Sync with</span> real nature</h3>
                            <p>We never used to change the real looks and colors, we have a different vision and perspective of nature.</p>
                        </div>
                        <ul class="team-item-social clearlist">
                            <li>
                                <a href="#." class="fa fa-facebook-square"></a>
                            </li>
                            <li>
                                <a href="#." class=" fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#." class="fa fa-skype"></a>
                            </li>
                            <li>
                                <a href="#." class="fa fa-pinterest"></a>
                            </li>
                        </ul>
                    </div>
                    <!--/ End Item Info -->
                </div>
                <!--/ End Team Item -->
                <!-- Team Item -->
                <div class="team-item">
                    <!-- Team Item Image -->
                    <div class="team-item-img">
                        <img src="img/team/Sathiya.jpg" alt="team member" />
                    </div>
                    <!--/ End Team Item Image -->
                    <!-- Team Item Name -->
                    <div class="team-item-name font-second">
                        <h4 class="">Sathiya</h4>
                        <span>Photographer</span>
                    </div>
                    <!--/ End Team Item Name -->
                    <!-- Team Item Info -->
                    <div class="team-item-info">
                        <div class="team-item-text">
                            <h3 class="font-second">Chooo Cute! <span>click..</span></h3>
                            <p>The shutter is always open to capture you, because its never happen again</p>
                        </div>
                        <ul class="team-item-social clearlist">
                            <li>
                                <a href="#." class=" fa fa-twitter"></a>
                            </li>
                            <li>
                                <a href="#." class="fa fa-skype"></a>
                            </li>
                            <li>
                                <a href="#." class="fa fa-pinterest"></a>
                            </li>
                        </ul>
                    </div>
                    <!--/ End Item Info -->
                </div>
                <!--/ End Team Item -->
                <!-- Team Item -->
            </div>
            <!--/ End Team Carousel -->
        </div>
        <!--/ End Team Items -->
    </div>
    <!-- /.container -->
</section>
<!--/ End Team Section -->