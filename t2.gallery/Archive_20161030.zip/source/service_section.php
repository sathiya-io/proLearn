<!-- Services Section -->
            <section id="services-section" class="services-section section">
                <div class="container">
                    <div class="section-title">
                        <div class=" section-title-more">
                            well covered and efficient
                        </div>
                        <div>
                            <h1 class="section-title-heading"><span>Our</span> Services</h1>
                        </div>
                    </div>
                    <div class="services-section-items padding-top-sm-10 row">
                        <div class="services-section-item col-sm-4 wow fadeInUpRightScale">
                            <div class="services-section-item-icon">
                                <i class="icon-picture"></i>
                            </div>
                            <h4 class="services-item-title font-second">Couple shoots</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-heart"></i>
                            </div>
                            <h4 class="services-item-title font-second">Marriage</h4>
                            <div class="services-section-item-text">
                                <p>you never think about it but it would happen one day because of you.</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpLeftScale">
                            <div class="services-section-item-icon">
                                <i class="icon-aperture"></i>
                            </div>
                            <h4 class="services-item-title font-second">Candid</h4>
                            <div class="services-section-item-text">
                                <p>Being one's self is what takes to be a perfect candid moments, T2 makes sure your lively moments are captured.</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpLeftScale">
                            <div class="services-section-item-icon">
                                <i class="icon-lightbulb"></i>
                            </div>
                            <h4 class="services-item-title font-second">Events</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-focus"></i>
                            </div>
                            <h4 class="services-item-title font-second">Infants & Kids Shoot</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                        <div class="services-section-item col-sm-4 margin-bottom-xs-40 wow fadeInUpScale">
                            <div class="services-section-item-icon">
                                <i class="icon-anchor"></i>
                            </div>
                            <h4 class="services-item-title font-second">Product Shoot</h4>
                            <div class="services-section-item-text">
                                <p>Magnam distinctio unde atque quos iusto illoim dignissimos hic. Dolore iusto illo, eaque eligendi itaque, iure facilis fugiat et..</p>
                            </div>
                        </div>
                        <!--/ End Services Section Item -->
                    </div>
                    <!--/.row -->
                </div>
                <!--/.container -->
            </section>
            <!--/ End Services Section -->