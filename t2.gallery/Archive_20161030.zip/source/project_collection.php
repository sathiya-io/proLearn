<!-- Works Items -->
<ul id="portfolio-container" class="portfolio-container masonry clearlist row portfolio-hover-effect">
    <li class="portfolio-item photo video col-sm-6 col-md-3 col-xs-12">
        <div class="portfolio-item-img">
        <?php 
            ini_set('display_errors', 'On');
            error_reporting(E_ALL);
            #$dirname = ['events', 'candid', 'couple', 'kids', 'marriage', 'products'];
            #$dirname = getAttribute('data-page');
            
                ?>
        
            <img src="../img/projects/candid/sample1/thumbnail.png" alt="portfolio" />
        </div>
        <div class="portfolio-item-info font-second">
            <h3 class="portfolio-item-title">Om!</h3>
            <div class="portfolio-item-detail">
                <p>Collection...!</p>
                <!-- LightBox Button -->
                <a href="" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="../img/portfolio/work01_lg.jpg"></a>
                <!--/ End LightBox Button -->
            </div>
        </div>
    </li>
    <li class="portfolio-item photo video col-sm-6 col-md-3 col-xs-12">
        <div class="portfolio-item-img">
            <img src="../img/400x360.png" alt="portfolio" />
        </div>
        <div class="portfolio-item-info font-second">
            <h3 class="portfolio-item-title">Kids</h3>
            <div class="portfolio-item-detail">
                <p>Collection...!</p>
                <!-- LightBox Button -->
                <a href="../img/portfolio/work01_lg.jpg" title="This is an image title" class="icon-magnifying-glass lightbox" data-lightbox-gallery="gallery1" data-lightbox-hidpi="../img/portfolio/work01_lg.jpg"></a>
                <!--/ End LightBox Button -->
            </div>
        </div>
    </li>
    <!--/ End Work Item -->
</ul>
<!--/ End Works Items -->