<? php
   <div id="footer">
        <div class="container">
            <a href="#"><span class="social social-facebook"></span></a>
            <a href="#"><span class="social social-twitter"></span></a>
            <a href="#"><span class="social social-instagram"></span></a>
            <div class="footernote">Copyright © Sathiyamoorthy Portal</div>
        </div>
    </div>

    <script type="text/javascript" src="source/bootstrap/js/bootstrap.js"></script> 
    <script type="text/javascript" src="source/bootstrap/js/npm.js"></script> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script type="text/javascript" src="source/bootstrap/js/script.js"></script> 