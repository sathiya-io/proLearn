<? php
<html>
    <head>
        <meta charset="UTF-8" />
        <link rel="icon" type="image/x-icon" href="favicon.ico" />
        <link href="source/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
        <link href="source/bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css" media="all">
        <link href="source/bootstrap/css/main.css" rel="stylesheet" type="text/css" media="all">
        <!--[if gte IE 9]>
            <link rel="stylesheet" type="text/css" href="css/ie9.css" />
        <![endif]-->
    </head>
    <nav id="menu" class="navbar navbar-default navbar-fixed-top">
        <div class="container"> 
        <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                  <!-- <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button> -->
                  <a class="navbar-brand" href="/">Sathiya</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://blog.sathiya.io" target="_blank">Blog</a></li>
                    <li><a href="http://photography.sathiya.io" target="_blank">Passion</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse --> 
          </div>
          <!-- /.container-fluid --> 
    </nav>