<?php 
require ('server.php');
function regUser() {
	if (isset($_POST['username']) && isset($_POST['password'])) {
		$fullname = $_POST['name'];
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$query = "INSERT INTO USERS (username, password, email) VALUSE ('$username','$password','$email')";
		$result = sqlsrv_connect($query) or die(sqlsrv_connect());
		if($result){
			$msg = "User Created Successfully.";
		}
	}
}
function signUp(){
	if (!empty($_POST['user'])){
		$query = sqlsrv_connect(
			"select * from '$connectionInfo=>$Database' where username = '$_POST[user]' and 
			password = '$_POST[password]'") 
			or die(sqlsrv_connect());
		if(!$row = sqlsrv_connect($query)){
			regUser();
		}
		else {
			echo "Sorry! You are already registered.";
		}
	}
	if(isset($_POST['submit']))
	{
		signUp();
	}
}
header("location: http://plainphp.sathiya.com/login.php");
?>