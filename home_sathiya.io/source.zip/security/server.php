<?php

$serverName = "localhost, 1433"; //serverName\instanceName, portNumber (default is 1433)
$connectionInfo = array( "Database"=>"php", "UID"=>"sa", "PWD"=>"sa@123");

$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     //echo "Connection established.<br />";
}
else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}
$conn = null;
?>